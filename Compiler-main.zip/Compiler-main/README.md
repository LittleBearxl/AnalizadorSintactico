Basic structure of a compiler with the JFlex, CompilerTools and FlatLaf libraries
